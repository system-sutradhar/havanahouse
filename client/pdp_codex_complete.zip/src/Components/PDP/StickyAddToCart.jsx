'use client';
import Button from '@mui/material/Button';

const StickyAddToCart = ({ onAddToCart }) => {
  return (
    <div className="sticky-cart-bar">
      <Button fullWidth variant="contained" color="primary" onClick={() => onAddToCart(1)}>
        Add to Cart
      </Button>
    </div>
  );
};

export default StickyAddToCart;
