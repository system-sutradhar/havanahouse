'use client';
import { useState } from 'react';

const DeliveryChecker = () => {
  const [pincode, setPincode] = useState('');
  const [message, setMessage] = useState('');

  const checkAvailability = () => {
    if (!pincode) return;
    // Replace with actual API call
    setMessage(pincode === '411001' ? 'Delivery available to your location.' : 'Not deliverable to this pincode.');
  };

  return (
    <div className="delivery-checker">
      <input
        type="text"
        placeholder="Enter Pincode"
        value={pincode}
        onChange={(e) => setPincode(e.target.value)}
      />
      <button onClick={checkAvailability}>Check</button>
      {message && <p>{message}</p>}
    </div>
  );
};

export default DeliveryChecker;
