'use client';

import { useEffect, useState, useContext } from 'react';
import ProductZoom from '@/Components/ProductZoom';
import ProductInfo from '@/Components/PDP/ProductInfo';
import Tabs from '@/Components/PDP/Tabs';
import StickyAddToCart from '@/Components/PDP/StickyAddToCart';
import DeliveryChecker from '@/Components/PDP/DeliveryChecker';
import RelatedProducts from '@/Components/PDP/RelatedProducts';
import TrustBadges from '@/Components/PDP/TrustBadges';
import SkeletonLoader from '@/Components/PDP/SkeletonLoader';
import { MyContext } from '@/context/ThemeContext';

const ProductDetailsPage = ({ params }) => {
  const [productData, setProductData] = useState(null);
  const [isAddedToMyList, setIsAddedToMyList] = useState(false);
  const context = useContext(MyContext);

  const id = params.productId;

  useEffect(() => {
    window.scrollTo(0, 0);
    const fetchProduct = async () => {
      const res = await fetch(`/api/products/${id}`);
      const data = await res.json();
      setProductData(data);
    };

    fetchProduct();
    const wishlist = JSON.parse(localStorage.getItem("myList")) || [];
    setIsAddedToMyList(wishlist.includes(id));
  }, [id]);

  const handleAddToCart = (quantity) => {
    console.log("Add to cart:", productData?.name, "Qty:", quantity);
  };

  if (!productData) return <SkeletonLoader />;

  return (
    <>
      <div className="pdp-container">
        <div className="left-section">
          <ProductZoom images={productData.images} discount={productData.discount} />
        </div>
        <div className="right-section">
          <ProductInfo
            product={productData}
            isAddedToMyList={isAddedToMyList}
            onAddToCart={handleAddToCart}
          />
          <DeliveryChecker />
          <TrustBadges />
        </div>
      </div>

      <Tabs description={productData.description} reviews={productData.reviews} />
      <RelatedProducts currentProductId={id} />
      <StickyAddToCart onAddToCart={handleAddToCart} />
    </>
  );
};

export default ProductDetailsPage;
